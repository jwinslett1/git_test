# TIFF spot-channel repair v3

Based on PhotoCraft `b097800e78405aeb2068113988898f991e707eb4`, with the
measured PSD polarity behavior from the supplied Experimental v2.1 patch applied
without reverting newer upstream PSD/PSB, palette, or text fixes.

## Data preserved

The supported DTF export layout is RGB with one spot channel, optionally with
transparency: RGB + straight transparency + spot = five samples. TIFF ExtraSamples
is `[2, 0]`, or `[0]` for opaque RGB + spot. The spot is an unspecified TIFF sample
identified as an ink by Photoshop image resources, not a second alpha sample.
Image resources are retained even when ordinary metadata embedding is disabled.
Names, spot color, solidity and channel kind come from the document. The supplied
`w1` is white, with 100% solidity, and these options survive round trips.

PhotoCraft coverage masks use zero for no ink; Photoshop spot plates use maximum
for no ink. Only spot samples are inverted on PSD export/import. The 8-bit v2.1
behavior is preserved; 16-bit integer and 32-bit float use the corresponding
65535-value / 1-value inversion. TIFF reuses the PSD export planes, without
inverting them a second time, and restores internal coverage on import.

The decoder retains extra sample planes separately from RGB and transparency,
including planar, chunky, either endian and BigTIFF input. Orienting a flat image
also orients its extra planes. Both layered and composite-only TIFF import restore
channel options from resources 1045 and 1077 (legacy 1007 display records are read).
An unreadable layer-data tag falls back to composite data while keeping the spot.
Truncated spot data is an error rather than an empty or missing plate.

## Embedded Photoshop layer data

An absent PSD global mask is no longer serialized as an empty TIFF `LMsk` record.
A TIFF mask record requires mask fields; absence is represented by omitting that
optional record. Layers and actual nonempty mask data remain present. Merged
transparency marker blocks precede the layer block, matching the ordering required
by Photoshop's 16/32-bit PSD model. Existing layer-data byte-order conversion,
channel compression and record-length handling remain in use.

The reporter (@jwinslett1) tested a backport to PhotoCraft 0.10.0 and confirmed
that two exported images opened correctly in Adobe Photoshop. Photoshop spot
options, composite-only import, and RIP plate coverage still need independent
verification; the report establishes successful opening, not every channel option.

## Tests

```sh
cargo check --locked -p photocraft
cargo test --locked -p photocraft-psd -p photocraft-codecs -p photocraft-io
cargo clippy --locked -p photocraft-psd -p photocraft-codecs -p photocraft-io --all-targets -- -D warnings
cargo xtask layers
cargo xtask wasm
cargo xtask test-corpus -p io -p codecs -p psd
```

Large user reference files stay outside source control. The two ignored tests
require explicit file paths; they fail if their requested file is missing:

```sh
PHOTOCRAFT_SPOT_PSD=/path/PTOtigercreek.psd \
  cargo test --locked -p photocraft-io --test tiff_spot supplied_photoshop_psd -- --ignored
PHOTOCRAFT_SPOT_TIFF=/path/PTOtigercreek.tif \
  cargo test --locked -p photocraft-io --test tiff_spot supplied_photoshop_tiff -- --ignored
```

Set `PHOTOCRAFT_SPOT_OUTPUT` to a directory to retain regenerated layered and
composite-only TIFFs for external inspection. The optional Python verifier shipped
with the output uses independent psdtags/tifffile readers to compare the supplied
PSD's layer planes, transparency and spot pixels against those TIFFs.

## Remaining verification and scope

The supplied PSD was accessible and tested. The supplied Photoshop TIFF exceeded
the attachment tool's 32 MiB transfer limit; its compatibility test remains unrun
until a ZIP-compressed copy or smaller Photoshop-saved crop is provided.

Verify in Adobe Photoshop that the generated layered TIFF retains editable
artwork/transparency and shows a separate `w1` Spot Channel with
white color and 100% solidity. Verify the same channel through Photoshop's Read
Composite Data route and reopen/resave in both applications. Confirm plate coverage
against the original and validate the production RIP separation before printing.

Export support here is one spot plane on RGB documents. Multiple extra channels
and non-RGB spot export retain the existing explicit unsupported-layout warning;
this change does not generalize them. No Windows executable or Adobe Photoshop
session was automated; Cargo validation ran on Linux. The reporter supplied the
manual Photoshop-opening confirmation described above.

## Validation results in this session

- Desktop `cargo check --locked -p photocraft`: passed on Linux/Rust 1.95.0.
- Full normal tests for `photocraft-psd`, `photocraft-codecs`, `photocraft-io`:
  1,907 passed, zero failed, 13 ignored. These include normal unit, integration
  and documentation tests; opt-in external corpus tests are separate.
- Explicit supplied PSD regression: one passed (run with `--ignored`).
- Strict Clippy for all targets of the three modified crates: passed.
- Workspace formatting and crate-layering validation: passed.
- Independent psdtags/tifffile verification of both generated TIFFs: passed;
  the layered file's RGBA layer samples match the original PSD exactly, and both
  files' transparency and spot samples match its merged planes exactly.
- Full corpus runner: blocked before tests by HTTP 403 downloading pinned PngSuite;
  HTTPS to the same host was also denied by the environment proxy. No checksum or
  TLS checks were disabled, and corpus passes are not claimed.
- Original supplied Photoshop TIFF regression: unrun, transfer exceeds 32 MiB.
- `cargo xtask wasm`: passed for all checked crates and the optional HEIF codec feature.

- Reporter @jwinslett1 manually confirmed that two images exported by the 0.10.0
  backport opened correctly in Adobe Photoshop.
