# TIFF spot-channel repair: PhotoCraft 0.15.1

Based on upstream `28f3c18c0d11d69005d224a0a5d5edc56f1fe858` (workspace
version 0.15.1). This replaces the previous 0.11/0.10 overlay; it is not a set
of old source files copied onto the new release. In particular, current DICOM
and IFF decode dispatch and import-only encode errors remain intact.

## Supported export

One spot channel in RGB or CMYK, with optional transparency, at 8-bit,
16-bit integer and 32-bit float depths. RGB + transparency + spot has five
samples; CMYK + transparency + spot has six. Without transparency these have
four and five samples respectively. TIFF ExtraSamples is `[2, 0]` with straight
transparency or `[0]` without it. The spot is an unspecified sample identified
by Photoshop channel metadata, never a second transparency channel.

CMYK TIFF uses separated photometric interpretation. Only its four color
planes undergo the existing PSD/TIFF CMYK convention conversion. Its alpha
and spot planes are independent. A single plain CMYK raster layer uses the
existing native flat-image path, preserving its original C/M/Y/K separations
instead of sending them through the RGB compositor. A new generic `encode_tiff_spot` entry point
replaces the old patch-only RGB writer. Source DPI, profiles and layer data
continue through the existing metadata/export paths.

## Polarity and layers

PhotoCraft's current document model uses coverage: zero = no ink, one = full
ink. PSD/Photoshop spot planes use the reverse convention. The conversion
occurs once on PSD import/export; TIFF reuses those exported spot bytes
without a second inversion and restores coverage on import. The patched PSD
behavior is preserved across all three supported depths. This does not change
the painting engine's internal convention or brush behavior.

The Photoshop layer-data repair omits an absent global mask instead of writing
an empty `LMsk` record, and puts merged-transparency marker blocks before the
layer block. Existing byte-order and layer channel compression code is reused.
Newer upstream PSD/PSB and other file-format code is retained.

TIFF import retains extra planes independently of the RGB/CMYK composite,
restores spot name/color/solidity, and handles layered and flat TIFF. Invalid
layer data can fall back to composite data while preserving the spot. Legacy
Pascal names (1006) are used when Unicode names (1045) are absent, keeping
transparency and DisplayInfo entries aligned. Both modern 1077 and legacy 1007
display resources are recognized. Missing/truncated spot pixels are errors.

## Verification

Synthetic tests cover RGB and CMYK, opaque/transparent, flat/layered, three
sample depths, four TIFF compression options, byte order, planar/chunky data,
orientation, malformed spot buffers, truncated planes, damaged layers and legacy
channel-name alignment. Supplied real Photoshop PSD/TIFF references are opt-in
ignored tests, run explicitly with `PHOTOCRAFT_SPOT_PSD` / `PHOTOCRAFT_SPOT_TIFF`.
Reference artwork is not committed or included in the replacement package.

The build's validation report records executed commands and actual outcomes.
Adobe Photoshop opening/painting and production RIP output must be checked
on the user's machine; Rust round trips do not establish real-app acceptance.
Credit for reporting and real Photoshop/printing testing: @jwinslett1.
